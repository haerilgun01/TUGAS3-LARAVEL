<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MahasiswaControllers;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// route salam
Route::get('/salam', function(){
    return "Assalamu'alaikum Sobat, Selamat Belajar Laravel";
});

//Routing dengan parameter
Route::get('/pegawai/{nama}/{divisi}',function($nama,$divisi){
    return 'Nama Pegawai :' .$nama.'<br/>Departemen : '.$divisi; 
});

//Menambahkan Route /Kabar
Route::get('/kabar',function() {
    return view('kondisi');
});

//Route Data Mahasiswa
Route::get('/mahasiswa', [MahasiswaControllers::class,'dataMahasiswa']);

//pertemuan 4
//menambahkan view model

Route::get('/hello', function () {
    return view('p4/hello', ['name' => 'Haeril']);
});

//menambahkan nilai
Route::get('/nilai', function(){
    return view('p4/nilai');
});

// Menambahkan daftar nilai
Route::get('/daftarnilai', function(){
    return view('/p4/daftar_nilai');
});

//Route Dasar Templat 

Route::get('phpframework', function (){ 
    return view('p4/layout/index');
});

