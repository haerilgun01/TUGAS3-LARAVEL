<?php
    namespace App\Http\Controllers;
    use Illuminate\Http\request;

    class MahasiswaControllers extends Controller
    {
        public function dataMahasiswa(){
            $mhs1 = 'Haeril'; $asal1 = 'Lombok';
            $mhs2 = 'Yazit'; $asal2 = 'Surabaya';
            $mhs3 = 'Arya'; $asal3 = 'Lombok';
            $mhs4 = 'Nanto'; $asal4 = 'jawa Barat';
            $mhs5 = 'Rio'; $asal5 = 'Jakarta';

            return view('data_mahasiswa',
                 compact('mhs1', 'mhs2', 'mhs3', 'mhs4','mhs5','asal1','asal2','asal3','asal4','asal5')
            );
        }
    }
?>