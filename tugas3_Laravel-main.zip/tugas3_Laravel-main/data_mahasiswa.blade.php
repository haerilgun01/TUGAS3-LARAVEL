<h3 align='center'>Data Mahasiswa</h3>

    <table border="1" align='center'>
        
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Mahasiswa</th>
                <th>Asal</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>{{ $mhs1 }}</td>
                <td>{{ $asal1 }}</td>
            </tr>
            <tr>
                <td>2</td>
                <td>{{ $mhs2 }}</td>
                <td>{{ $asal2 }}</td>
            </tr>
            <tr>
                <td>3</td>
                <td>{{ $mhs3 }}</td>
                <td>{{ $asal3 }}</td>
            </tr>
            <tr>
                <td>4</td>
                <td>{{ $mhs4 }}</td>
                <td>{{ $asal4 }}</td>
            </tr>
            <tr>
                <td>5</td>
                <td>{{ $mhs5 }}</td>
                <td>{{ $asal5 }}</td>
            </tr>
        </tbody>
    </table>
</body>
</html>

